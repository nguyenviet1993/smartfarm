module IStats
  VERSION = '1.5.0'
end
